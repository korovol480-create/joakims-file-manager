package com.example.mydm

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val engine get() = (application as App).engine
    private val clip = mutableStateOf<String?>(null)
    private var lastClip: String? = null
    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        if (savedInstanceState == null) handleIntent(intent)
        lifecycleScope.launch {
            engine.messages.collect { Toast.makeText(this@MainActivity, it, Toast.LENGTH_SHORT).show() }
        }
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen(engine, clip.value) { clip.value = null } }
            }
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIntent(intent) }

    private fun handleIntent(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val url = Regex("https?://\\S+").find(i.getStringExtra(Intent.EXTRA_TEXT).orEmpty())?.value ?: return
        engine.add(url)
    }

    // Clipboard can only be read once the window has focus (Android 10+)
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus) return
        val cm = getSystemService(ClipboardManager::class.java)
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()?.trim()
        if (text != null && text.isUrl() && text != lastClip) { lastClip = text; clip.value = text }
    }
}

@Composable
fun Screen(engine: DownloadEngine, clipLink: String?, onClipDone: () -> Unit) {
    val ctx = LocalContext.current
    val flow = remember { engine.dao.observeAll() }
    val list by flow.collectAsState(initial = emptyList())
    val speeds by engine.speeds.collectAsState()
    var text by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Joakim's File Manager", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text,
                onValueChange = { v ->
                    // a paste adds many characters at once; typing adds one
                    if (v.length - text.length > 5 && v.trim().isUrl()) { engine.add(v.trim()); text = "" } else text = v
                },
                label = { Text("Paste link") }, singleLine = true, modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val c = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString()?.trim().orEmpty()
                val link = if (text.trim().isUrl()) text.trim() else c
                if (link.isUrl()) { engine.add(link); text = "" }
                else Toast.makeText(ctx, "No link found", Toast.LENGTH_SHORT).show()
            }) { Text("Paste") }
        }
        Spacer(Modifier.height(12.dp))
        if (list.isEmpty()) Text("No downloads yet. Paste a link, or Share a link to this app.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { d -> ItemCard(d, speeds[d.id] ?: 0L, engine) }
        }
    }

    if (clipLink != null) AlertDialog(
        onDismissRequest = onClipDone,
        title = { Text("Download this link?") },
        text = { Text(clipLink, maxLines = 3, overflow = TextOverflow.Ellipsis) },
        confirmButton = { TextButton({ engine.add(clipLink); onClipDone() }) { Text("Download") } },
        dismissButton = { TextButton(onClipDone) { Text("Cancel") } }
    )
}

@Composable
fun ItemCard(d: Item, speed: Long, engine: DownloadEngine) {
    val ctx = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(d.fileName, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            if (d.totalBytes > 0) LinearProgressIndicator(
                progress = { (d.downloadedBytes.toFloat() / d.totalBytes).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth()
            ) else if (d.status == "DOWNLOADING") LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(4.dp))
            val size = if (d.totalBytes > 0) " / ${fmtBytes(d.totalBytes)}" else ""
            Text(
                when (d.status) {
                    "DOWNLOADING" -> "${fmtBytes(d.downloadedBytes)}$size • ${fmtSpeed(speed)}"
                    "COMPLETED" -> "Done • ${fmtBytes(d.totalBytes)}"
                    "FAILED" -> "Failed: ${d.error}"
                    "PAUSED" -> "Paused • ${fmtBytes(d.downloadedBytes)}$size"
                    else -> "Queued"
                },
                style = MaterialTheme.typography.bodySmall
            )
            Row {
                when (d.status) {
                    "DOWNLOADING", "QUEUED" -> TextButton({ engine.pause(d.id) }) { Text("Pause") }
                    "PAUSED", "FAILED" -> TextButton({ engine.resume(d.id) }) { Text("Resume") }
                    "COMPLETED" -> TextButton({
                        try {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(d.savedUri), d.mime)
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            )
                        } catch (e: Exception) { Toast.makeText(ctx, "Can't open file", Toast.LENGTH_SHORT).show() }
                    }) { Text("Open") }
                }
                TextButton({ engine.remove(d.id) }) { Text("Remove") }
            }
        }
    }
}
