package com.example.mydm

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.combine

class DownloadService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var started = false
    private var lastId = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastId = startId
        val engine = (application as App).engine
        if (intent?.action == ACTION_PAUSE_ALL) engine.pauseAll()
        ServiceCompat.startForeground(this, 1, build(emptyList(), emptyMap()), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (!started) {
            started = true
            scope.launch {
                combine(engine.dao.observeAll(), engine.speeds) { a, b -> a to b }.collect { (items, speeds) ->
                    val active = items.filter { it.status == "DOWNLOADING" || it.status == "QUEUED" }
                    if (active.isEmpty()) {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf(lastId)
                    } else getSystemService(NotificationManager::class.java).notify(1, build(active, speeds))
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun build(active: List<Item>, speeds: Map<Long, Long>): Notification {
        val known = active.filter { it.totalBytes > 0 }
        val total = known.sumOf { it.totalBytes }
        val done = known.sumOf { it.downloadedBytes }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val pause = PendingIntent.getService(
            this, 1, Intent(this, DownloadService::class.java).setAction(ACTION_PAUSE_ALL), PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, App.CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(if (active.isEmpty()) "Starting…" else "${active.size} download(s)")
            .setContentText(if (active.isEmpty()) "" else "${active.first().fileName} • ${fmtSpeed(speeds.values.sum())}")
            .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
            .addAction(0, "Pause all", pause)
        if (total > 0) b.setProgress(100, (done * 100 / total).toInt(), false) else b.setProgress(0, 0, true)
        return b.build()
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    companion object { const val ACTION_PAUSE_ALL = "com.example.mydm.PAUSE_ALL" }
}
