package com.example.mydm

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "downloads")
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val fileName: String,
    val totalBytes: Long = -1,
    val downloadedBytes: Long = 0,
    val status: String = "QUEUED", // QUEUED DOWNLOADING PAUSED COMPLETED FAILED
    val segments: String = "",
    val acceptRanges: Boolean = false,
    val error: String? = null,
    val savedUri: String? = null,
    val mime: String = "application/octet-stream"
)

@Dao
interface ItemDao {
    @Query("SELECT * FROM downloads ORDER BY id DESC") fun observeAll(): Flow<List<Item>>
    @Query("SELECT * FROM downloads WHERE id=:id") suspend fun get(id: Long): Item?
    @Query("SELECT * FROM downloads WHERE status='QUEUED' ORDER BY id") suspend fun queued(): List<Item>
    @Insert suspend fun insert(i: Item): Long
    @Query("DELETE FROM downloads WHERE id=:id") suspend fun delete(id: Long)
    @Query("UPDATE downloads SET status=:s, error=:e WHERE id=:id") suspend fun setStatus(id: Long, s: String, e: String?)
    @Query("UPDATE downloads SET downloadedBytes=:d, segments=:seg WHERE id=:id") suspend fun progress(id: Long, d: Long, seg: String)
    @Query("UPDATE downloads SET status='COMPLETED', totalBytes=:size, downloadedBytes=:size, savedUri=:uri, error=NULL, segments='' WHERE id=:id")
    suspend fun complete(id: Long, size: Long, uri: String)
    @Query("UPDATE downloads SET status='PAUSED' WHERE status IN ('DOWNLOADING','QUEUED')") suspend fun resetActive()
}

@Database(entities = [Item::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() { abstract fun dao(): ItemDao }
