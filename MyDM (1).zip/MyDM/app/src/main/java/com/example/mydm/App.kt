package com.example.mydm

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class App : Application() {
    lateinit var engine: DownloadEngine
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_PROGRESS, "Active downloads", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Completed downloads", NotificationManager.IMPORTANCE_DEFAULT))
        engine = DownloadEngine(this)
    }
    companion object { const val CH_PROGRESS = "progress"; const val CH_DONE = "done" }
}
