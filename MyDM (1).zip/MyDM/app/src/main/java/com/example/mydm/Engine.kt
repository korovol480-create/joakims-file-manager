package com.example.mydm

import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.room.Room
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.URLDecoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** One byte range of a file. pos = next byte to download. */
class Seg(val start: Long, val end: Long, pos0: Long) {
    @Volatile var pos: Long = pos0
    @Volatile var finished = false
    fun done() = if (end >= 0) pos > end else finished
    fun downloaded() = pos - start
}

private class Probe(val name: String, val total: Long, val ranges: Boolean, val mime: String?)

class DownloadEngine(private val ctx: Context) {
    val dao = Room.databaseBuilder(ctx, AppDb::class.java, "dm.db").build().dao()
    val speeds = MutableStateFlow<Map<Long, Long>>(emptyMap())
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = ConcurrentHashMap<Long, Job>()
    private val calls = ConcurrentHashMap<Long, MutableSet<Call>>()
    private val stops = ConcurrentHashMap<Long, String>()
    private val mutex = Mutex()
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    init { scope.launch { dao.resetActive() } }

    // ---------- public API ----------
    fun add(url: String) {
        scope.launch {
            try {
                val p = probe(url)
                val ext = p.name.substringAfterLast('.', "").lowercase()
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                    ?: p.mime?.substringBefore(';')?.trim()
                    ?: "application/octet-stream"
                dao.insert(Item(url = url, fileName = p.name, totalBytes = p.total, acceptRanges = p.ranges, mime = mime))
                messages.tryEmit("Added: ${p.name}")
                pump()
                startService()
            } catch (e: Exception) {
                messages.tryEmit("Can't add link: ${e.message}")
            }
        }
    }

    fun resume(id: Long) {
        scope.launch { dao.setStatus(id, "QUEUED", null); pump(); startService() }
    }
    fun pause(id: Long) = stop(id, "PAUSE")
    fun remove(id: Long) = stop(id, "DELETE")
    fun pauseAll() {
        jobs.keys.forEach { pause(it) }
        scope.launch { dao.resetActive() }
    }

    // ---------- queue ----------
    private fun startService() {
        try { ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java)) } catch (_: Exception) {}
    }

    private fun pump() {
        scope.launch {
            mutex.withLock {
                for (q in dao.queued()) {
                    if (jobs.size >= MAX_ACTIVE) break
                    if (jobs.containsKey(q.id)) continue
                    val job = scope.launch(start = CoroutineStart.LAZY) {
                        try { run(q.id) } finally { jobs.remove(q.id); pump() }
                    }
                    jobs[q.id] = job
                    job.start()
                }
            }
        }
    }

    private fun stop(id: Long, how: String) {
        val job = jobs[id]
        if (job != null) {
            stops[id] = how
            calls[id]?.forEach { it.cancel() }
            job.cancel()
        } else scope.launch {
            if (how == "DELETE") { tmp(id).delete(); dao.delete(id) } else dao.setStatus(id, "PAUSED", null)
        }
    }

    private fun tmp(id: Long) = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "tmp/$id.part")

    // ---------- one download ----------
    private suspend fun run(id: Long) {
        val item = dao.get(id) ?: return
        val file = tmp(id)
        file.parentFile?.mkdirs()
        var segs: List<Seg> = emptyList()
        try {
            dao.setStatus(id, "DOWNLOADING", null)
            val total = item.totalBytes
            val ranged = item.acceptRanges && total > 0
            segs = if (ranged) parse(item.segments) else emptyList()
            if (segs.isNotEmpty() && !file.exists()) segs = emptyList()
            if (segs.isEmpty()) {
                file.delete()
                segs = if (ranged && total > 1_000_000) {
                    val part = (total + CONNECTIONS - 1) / CONNECTIONS
                    (0 until CONNECTIONS).map { i -> Seg(i * part, minOf(total, (i + 1) * part) - 1, i * part) }
                } else listOf(Seg(0, if (total > 0) total - 1 else -1, 0))
                if (total > 0) RandomAccessFile(file, "rw").use { it.setLength(total) }
            }
            val work = segs
            coroutineScope {
                val ticker = launch {
                    var last = work.sumOf { it.downloaded() }
                    var t = System.currentTimeMillis()
                    while (true) {
                        delay(700)
                        val d = work.sumOf { it.downloaded() }
                        val now = System.currentTimeMillis()
                        speeds.update { it + (id to (d - last) * 1000 / maxOf(1L, now - t)) }
                        last = d; t = now
                        dao.progress(id, d, serialize(work))
                    }
                }
                work.filter { !it.done() }.map { s -> async { fetch(item.url, id, s, file, ranged) } }.awaitAll()
                ticker.cancel()
            }
            val size = file.length()
            if (total > 0 && size != total) throw IOException("Size mismatch ($size / $total)")
            val uri = saveToDownloads(file, item.fileName, item.mime)
            dao.complete(id, size, uri.toString())
            notifyDone(id, item.fileName)
        } catch (e: Throwable) {
            withContext(NonCancellable) {
                val how = stops.remove(id)
                if (how == "DELETE") {
                    file.delete(); dao.delete(id)
                } else {
                    if (segs.isNotEmpty()) dao.progress(id, segs.sumOf { it.downloaded() }, serialize(segs))
                    if (how != null || e is CancellationException) dao.setStatus(id, "PAUSED", null)
                    else dao.setStatus(id, "FAILED", e.message ?: e.javaClass.simpleName)
                }
            }
        } finally {
            speeds.update { it - id }
            calls.remove(id)
        }
    }

    private suspend fun fetch(url: String, id: Long, seg: Seg, file: File, ranged: Boolean) {
        var fails = 0
        while (!seg.done()) {
            try {
                if (!ranged) seg.pos = seg.start
                val b = req(url)
                if (ranged) b.header("Range", "bytes=${seg.pos}-${seg.end}")
                val call = client.newCall(b.build())
                calls.getOrPut(id) { ConcurrentHashMap.newKeySet() }.add(call)
                call.execute().use { r ->
                    if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                    if (ranged && r.code != 206) throw IOException("Server ignored range request")
                    val body = r.body ?: throw IOException("Empty response")
                    RandomAccessFile(file, "rw").use { raf ->
                        raf.seek(seg.pos)
                        val buf = ByteArray(65536)
                        body.byteStream().use { inp ->
                            while (true) {
                                currentCoroutineContext().ensureActive()
                                val want = if (seg.end >= 0) minOf(buf.size.toLong(), seg.end - seg.pos + 1).toInt() else buf.size
                                if (want <= 0) break
                                val n = inp.read(buf, 0, want)
                                if (n < 0) break
                                raf.write(buf, 0, n)
                                seg.pos += n
                            }
                        }
                    }
                }
                if (seg.end < 0) seg.finished = true
                if (!seg.done()) throw IOException("Connection closed early")
            } catch (e: IOException) {
                if (stops.containsKey(id) || ++fails >= 4) throw e
                delay(1500L * fails)
            }
        }
    }

    // ---------- helpers ----------
    private fun req(url: String) = Request.Builder().url(url)
        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) MyDM/1.0")
        .header("Accept-Encoding", "identity")

    private fun probe(url: String): Probe {
        try {
            client.newCall(req(url).head().build()).execute().use { r ->
                if (r.isSuccessful) return Probe(
                    fileName(r), r.header("Content-Length")?.toLongOrNull() ?: -1,
                    r.header("Accept-Ranges")?.contains("bytes", true) == true, r.header("Content-Type")
                )
            }
        } catch (_: IOException) {}
        return client.newCall(req(url).header("Range", "bytes=0-0").build()).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val partial = r.code == 206
            val total = if (partial) r.header("Content-Range")?.substringAfter('/')?.toLongOrNull() ?: -1
                        else r.header("Content-Length")?.toLongOrNull() ?: -1
            Probe(fileName(r), total, partial && total > 0, r.header("Content-Type"))
        }
    }

    private fun fileName(r: Response): String {
        val cd = r.header("Content-Disposition").orEmpty()
        val fromCd = Regex("filename\\*=(?:UTF-8|utf-8)''([^;]+)").find(cd)?.groupValues?.get(1)
            ?.let { runCatching { URLDecoder.decode(it, "UTF-8") }.getOrNull() }
            ?: Regex("filename=\"?([^\";]+)\"?").find(cd)?.groupValues?.get(1)
        val raw = if (!fromCd.isNullOrBlank()) fromCd
            else runCatching { URLDecoder.decode(r.request.url.pathSegments.last(), "UTF-8") }.getOrDefault("")
        return raw.ifBlank { "download" }.replace(Regex("[\\\\/:*?\"<>|]"), "_")
    }

    private fun serialize(s: List<Seg>) = s.joinToString(";") { "${it.start},${it.end},${it.pos}" }
    private fun parse(s: String): List<Seg> =
        if (s.isBlank()) emptyList()
        else s.split(";").map { p -> p.split(",").let { Seg(it[0].toLong(), it[1].toLong(), it[2].toLong()) } }

    private fun saveToDownloads(src: File, name: String, mime: String): Uri {
        val resolver = ctx.contentResolver
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MyDM")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw IOException("Can't create file in Downloads")
        resolver.openOutputStream(uri)!!.use { out -> src.inputStream().use { it.copyTo(out) } }
        v.clear(); v.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(uri, v, null, null)
        src.delete()
        return uri
    }

    private fun notifyDone(id: Long, name: String) {
        val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, App.CH_DONE)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Download complete").setContentText(name)
            .setContentIntent(pi).setAutoCancel(true).build()
        try { NotificationManagerCompat.from(ctx).notify(1000 + id.toInt(), n) } catch (_: SecurityException) {}
    }

    private companion object { const val MAX_ACTIVE = 3; const val CONNECTIONS = 4 }
}
